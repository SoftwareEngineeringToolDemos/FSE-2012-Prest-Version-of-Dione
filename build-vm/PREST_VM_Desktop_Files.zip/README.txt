-----------------------------------------------------------------
Run your own Virtual Machine on loaded Vagrant
-----------------------------------------------------------------
Here's how you can spin up a Virtual Machine for PREST:

The "prest_3_02" directory contains the files and scripts related to the PREST tool.
This VM will contain the "PREST" Tool.

What is already done with the vagrant and the setup scripts:
1. Vagrant is setup with Ubuntu.
2. The PREST tool is imported from the shared vagrant folder.
3. The tool's demo presentation and installation YouTube videos are also imported on desktop.
4. The Installation.txt file explains the whole process of downloading and installation of the tool.
5. The tool is compiled and ready to be run because of the setup.sh script which runs on startup.
6. The Terminal window opens automatically on startup with its working directory as the Prest tool's directory and listing all the files.

Follow this process to run the PREST tool:
1. In the opened terminal window, run the following command:
   ./prest ex_pedigrees ex_chromfiles 1
   This will give an output for the sample inputs provided with a set of statistical analysis.
2. In the same terminal window, run the following command:
   ./prest ex_pedigrees ex_chromfiles 2
   This will give an output for the sample inputs provided with a set of statistical analysis.
3. In the same terminal window we can run another alternate analysis with the following command with the sample inputs:
   ./altertest ex_altertest_input ex_chromfiles
   This will provide an output for the sample inputs provided with a set of statistical analysis.

Note: The login credentials for the guest vagrant VM are:
Username: vagrant
Password: vagrant
Please do not interact with the VM until all of the activity in the command window has completed.
