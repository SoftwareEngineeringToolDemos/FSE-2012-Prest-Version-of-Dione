./prest ex_pedigree ex_chromfiles 1
./prest ex_pedigree ex_chromfiles 2

./altertest ex_pedigree ex_altertest_input ex_chromfiles
